MIGRATIONS_TABLE_NAME: str = "migrations_table"
