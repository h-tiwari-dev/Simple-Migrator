# Simple Migrator

A simple tool written in python to run simple migrations.
