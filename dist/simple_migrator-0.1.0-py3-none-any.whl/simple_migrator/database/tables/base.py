from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    pass


# from sqlalchemy.ext.declarative import declarative_base
#
# Base = declarative_base()
